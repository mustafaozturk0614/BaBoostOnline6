package com.bilgeadam.lesson020.pokemon;

public class SuPokemonu extends Pokemon {

	int suBasincGucu;
	int yuzmeHizi;

}
