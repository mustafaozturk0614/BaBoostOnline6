package com.bilgeadam.lesson020.pokemon;

public class HavaPokemonu extends Pokemon {

	double kanatBoyu;
	int maxIrtifa;

}
