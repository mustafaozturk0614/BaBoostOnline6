package com.bilgeadam.lesson020.pokemon;

public class AtesPokemonu extends Pokemon {

	private int yakicilikG�c�;

	public AtesPokemonu() {
		this.yakicilikG�c� = 100;
	}

	public AtesPokemonu(int yakicilikG�c�) {

		this.yakicilikG�c� = yakicilikG�c�;
	}

	public int getYakicilikG�c�() {
		return yakicilikG�c�;
	}

}
