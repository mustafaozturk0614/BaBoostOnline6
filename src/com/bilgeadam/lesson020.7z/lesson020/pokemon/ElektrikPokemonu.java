package com.bilgeadam.lesson020.pokemon;

public class ElektrikPokemonu extends Pokemon {

	int voltaj;

}
