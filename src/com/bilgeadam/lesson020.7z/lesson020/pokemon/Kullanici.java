package com.bilgeadam.lesson020.pokemon;

public class Kullanici {

	String ad;
	Pokemon[] pokemonlar;

}
