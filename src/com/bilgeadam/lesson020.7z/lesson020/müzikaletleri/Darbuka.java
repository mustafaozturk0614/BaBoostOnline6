package com.bilgeadam.lesson020.m�zikaletleri;

public class Darbuka extends Vurmal�MuzikAletleri {

}
