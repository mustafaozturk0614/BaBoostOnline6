package com.bilgeadam.lesson020.m�zikaletleri;

public class UflemeliMuzikAletleri extends M�zikAleti {

	String ag�zYap�s�;
	int delikSayisi;

}
