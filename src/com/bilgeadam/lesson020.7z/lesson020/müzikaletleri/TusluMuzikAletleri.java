package com.bilgeadam.lesson020.m�zikaletleri;

public class TusluMuzikAletleri extends M�zikAleti {

	int tusSayisi;
	boolean tas�nabilirMi;

}
