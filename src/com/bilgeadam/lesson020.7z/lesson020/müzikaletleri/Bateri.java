package com.bilgeadam.lesson020.m�zikaletleri;

public class Bateri extends Vurmal�MuzikAletleri {

}
