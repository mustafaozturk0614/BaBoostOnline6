package com.bilgeadam.lesson020.m�zikaletleri;

public class Vurmal�MuzikAletleri extends M�zikAleti {

	double yuzeyGenisli�i;

}
