package com.bilgeadam.lesson020.m�zikaletleri;

public class TelliMuzikAletleri extends M�zikAleti {

	int telSayisi;

	public void telleriDegistir() {

		System.out.println("Teller de�i�ti .....");

	}
}
