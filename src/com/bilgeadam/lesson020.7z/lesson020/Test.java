package com.bilgeadam.lesson020;

public class Test {
	String ad;

	public static void main(String[] args) {
		// Object
		// this
		// super
		// ovverride
		// constructor
		//

	}

}
