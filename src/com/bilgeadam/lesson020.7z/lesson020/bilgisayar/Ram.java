package com.bilgeadam.lesson020.bilgisayar;

public class Ram extends DahiliDonanim {

}
