package com.bilgeadam.lesson020.bilgisayar;

public class HariciDonanim extends Donan�m {

}
