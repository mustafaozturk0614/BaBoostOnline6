package com.bilgeadam.lesson020.bilgisayar;

public class Donan�m {

}
