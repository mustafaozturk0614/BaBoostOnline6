package com.bilgeadam.lesson020.bilgisayar;

public class Kasa {

}
