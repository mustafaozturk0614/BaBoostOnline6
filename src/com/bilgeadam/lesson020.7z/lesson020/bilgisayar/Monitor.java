package com.bilgeadam.lesson020.bilgisayar;

public class Monitor extends HariciDonanim {

}
