package com.bilgeadam.lesson020.bilgisayar;

public class DahiliDonanim extends Donan�m {

}
