package com.bilgeadam.lesson020.bilgisayar;

public class Klavye extends HariciDonanim {

}
