package com.bilgeadam.lesson020.bilgisayar;

public class Islemci extends DahiliDonanim {

	int h�z;

}
