package com.bilgeadam.lesson026.footballapp;

public interface ITakim {

	void defansOlustur();

	void ortaSahaOlustur();

	void forvetOlustur();

}
