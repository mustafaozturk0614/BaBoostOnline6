package com.bilgeadam.lesson031;

public class Test {

	public static void main(String[] args) {
		PlakaTahmin plakaTahmin = new PlakaTahmin();

		plakaTahmin.mapOlustur();
		plakaTahmin.menu();

	}
}
