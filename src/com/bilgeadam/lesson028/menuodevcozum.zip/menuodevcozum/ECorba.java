package com.bilgeadam.lesson028.menuodevcozum;

public enum ECorba {

	MERCIMEK, EZOGEL�N, TARHANA, DOMATES, YAYLA, YES�LMERC�MEK, ISKEMBE, SEHR�YE, MANTAR,
}
