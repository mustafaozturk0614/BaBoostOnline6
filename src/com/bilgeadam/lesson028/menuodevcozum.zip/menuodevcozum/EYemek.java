package com.bilgeadam.lesson028.menuodevcozum;

public enum EYemek {

	PILAV, KURUFASULYE, NOHUT, DOLMA, TURLU, PATLICANKEBAP, PIRASA, BAMYA, MANTI, KARNIYARIK, SULUKOFTE, TAVUKSOTE
}
