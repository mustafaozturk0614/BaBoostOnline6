package com.bilgeadam.lesson028.menuodevcozum;

public enum ETatli {

	EKMEKKADAYIFI, REVANI, KEMALPASA, KUNEFE, SUTLAC, PUD�NG, MUHALLABE�, KAZANDIBI, BAKLAVA
}
