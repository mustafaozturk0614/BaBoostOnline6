package com.bilgeadam.lesson028.menuodevcozum;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class MenuManager {

	public ECorba corbaBelirle() {
		int uzunluk = ECorba.values().length;
		return ECorba.values()[randomIndex(uzunluk)];
	}

	public Enum menuBelirle(Enum[] dizi) {
		return dizi[randomIndex(dizi.length)];
	}

	public int randomIndex(int uzunluk) {
		Random random = new Random();
		return random.nextInt(uzunluk);
	}

	public Enum icecekBelirle(EIcecekler[] dizi) {
		int uzunluk = dizi.length;
		int index = randomIndex(uzunluk);

		while (dizi[index].isAtandimi()) {
			index = randomIndex(uzunluk);
		}

		dizi[index].setAtandimi(true);
		return dizi[index];

	}

	public Enum menuBelirle2(Enum[] dizi) {
		List<Enum> list = Arrays.asList(dizi);
		Enum value = null;

		while (!list.isEmpty()) {
			int index = randomIndex(list.size());
			value = list.get(index);
			System.out.println(value);
			list.remove(index);

		}

		return value;
	}

	public Menu menuOlustur() {
		Menu menu = new Menu();
		menu.setCorba((ECorba) menuBelirle(ECorba.values()));
		menu.setYemek((EYemek) menuBelirle(EYemek.values()));
		menu.setTatli((ETatli) menuBelirle(ETatli.values()));
		menu.setIcecek((EIcecekler) menuBelirle2(EIcecekler.values()));
		return menu;
	}

	public void haftal�kMenu() {
		EGun[] gunler = EGun.values();
		// {EGun.PAZARTES�,EGun.SALI,EGun.CARSAMBA.....}
		for (EGun gun : gunler) {
			System.out.println(gun.ordinal() + 1 + "-" + gun);
			System.out.println(menuOlustur());
		}
	}

	public static void main(String[] args) {

		MenuManager menuManager = new MenuManager();

		menuManager.haftal�kMenu();
	}

}
