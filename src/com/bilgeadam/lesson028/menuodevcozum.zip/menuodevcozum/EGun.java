package com.bilgeadam.lesson028.menuodevcozum;

public enum EGun {

	PAZARTES�, SALI, CARSAMBA, PERSEMBE, CUMA, CUMARTES�, PAZAR
}
