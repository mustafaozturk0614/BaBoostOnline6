package com.bilgeadam.lesson022.cal�san;

public class InsanKaynaklar� {

}
